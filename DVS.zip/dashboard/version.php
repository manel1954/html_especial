<?php
define("VERSION", "20180404-3 (".getGitVersion().")");
?>
