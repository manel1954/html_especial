#!/usr/local/bin/node

console.log("hhhhhhhhh")
