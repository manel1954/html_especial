
<?php
session_start();

$pass =($_POST['pass']);

//$pass="ea3eiz";
exec("sed -i '5c \$mipass=\"$pass\"\;' /var/www/html/dvs/dentro.php");
header("Location:index_dvswitch_buster.php");
?>
