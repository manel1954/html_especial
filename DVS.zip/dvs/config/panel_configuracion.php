<?php 
session_start();





$ambe_activo = exec("sed -n '24p'  /opt/Analog_Bridge/Analog_Bridge.ini");
$ambe_activo = substr("$ambe_activo", 18, 4);

$ip_ambe = exec("sed -n '88p'  /opt/Analog_Bridge/Analog_Bridge.ini");
$ip_ambe = substr("$ip_ambe", 10, 16);

$puerto_ambe = exec("sed -n '89p'  /opt/Analog_Bridge/Analog_Bridge.ini");
$puerto_ambe = substr("$puerto_ambe", 9, 10);



if ($dmr=="O")
{
    $dmr="DMR+";

//=======================================
if ($IPCS22=="Address=217.61.2.11"){
    $IPCS22="Catalunya";
}

if ($IPCS22=="Address=212.237.3.141"){
    $IPCS22="EA-Hotspot";
}

if ($IPCS22=="Address=94.177.189.17"){
    $IPCS22="EA-RPTR";
}

if ($IPCS22=="Address=217.61.97.204"){
    $IPCS22="EA1Master";
}
if ($IPCS22=="Address=185.47.129.230"){
    $IPCS22="EA2Master";
}
if ($IPCS22=="Address=212.237.4.86"){
    $IPCS22="EA3-RPTR";
}
if ($IPCS22=="Address=89.36.222.146"){
    $IPCS22="EA3Master";
}
if ($IPCS22=="Address=80.211.226.37"){
    $IPCS22="EA4Master";
}
if ($IPCS22=="Address=217.61.98.58"){
    $IPCS22="EA5Master";
}
if ($IPCS22=="Address=212.237.50.28"){
    $IPCS22="EA7Master";
}
if ($OPTION1=="4000"){
    $OPTION = substr("$OPTION", 42, 5);
}
//==========================================
else {
    $OPTION = substr("$OPTION", 17, 4);
    //$IPCS22="";
}

}
else {
    $dmr="BRANDMEISTER";
    $OPTION="";
    $IPCS22="";
}

$sistema = exec("sed -n '1p'  /opt/Analog_Bridge/Analog_Bridge.ini");
$sistema = substr("$sistema", 2, 3);

if ($sistema=="FCS")
{
    $sistema="FCS";
    $OPTION="";
    $sala_fcs = exec("sed -n '41p' /home/pi/YSFClients/YSFGateway/YSFGateway.ini");
    $sala_fcs = substr("$sala_fcs", 8, 15);  
    $IPCS22=$sala_fcs;
}
if ($sistema=="esp")
{
    $sistema="ESPECIAL";
}

if ($sistema=="dmr")
{
    $sistema=$dmr;
}
elseif ($sistema=="dst")
{
    $sistema="D-STAR";
    $OPTION="";
    $reflector_dstar = exec("sed -n '18p' /etc/ircddbgateway");
    $reflector_dstar = substr("$reflector_dstar", 11, 8);
    $IPCS22=$reflector_dstar;
}
elseif ($sistema=="nxd")
{
    $sistema="NXDN";
    $OPTION="";
    $sala_nxdn = exec("sed -n '10p' /opt/NXDNClients/NXDNGateway/private/NXDNHosts.txt");
    $sala_nxdn = substr("$sala_nxdn", 0, 5);
    $IPCS22=$sala_nxdn;
}
elseif ($sistema=="ysf")
{
    $sistema="YSF";
    $OPTION="";
    $IPCS22="";
}

$version_dvswitch = exec("sed -n '11p'  /home/pi/info.ini");
$id = exec("sed -n '38p'  /opt/Analog_Bridge/Analog_Bridge.ini");
$id = substr("$id", 15, 9);

$id2 = exec("sed -n '3p'  /opt/MMDVM_Bridge/MMDVM_Bridge.ini");
$id2 = substr("$id2", 3, 9);

$indicativo = exec("sed -n '2p' /opt/MMDVM_Bridge/MMDVM_Bridge.ini");
$indicativo = substr("$indicativo", 9, 7);

$port = exec("sed -n '55p'  /opt/Analog_Bridge/Analog_Bridge.ini");
$port = substr("$port", 9, 5);

$location = exec("sed -n '14p' /opt/MMDVM_Bridge/MMDVM_Bridge.ini");
$location = substr("$location", 9, 30);

$url = exec("sed -n '16p' /opt/MMDVM_Bridge/MMDVM_Bridge.ini");
$url = substr("$url", 4, 30);

$Latitude = exec("sed -n '11p' /opt/MMDVM_Bridge/MMDVM_Bridge.ini");
$Latitude = substr("$Latitude", 9, 9);

$Longitude = exec("sed -n '12p' /opt/MMDVM_Bridge/MMDVM_Bridge.ini");
$Longitude = substr("$Longitude", 10, 9);

$reflector_dstar = exec("sed -n '18p' /etc/ircddbgateway");
$reflector_dstar = substr("$reflector_dstar", 11, 8);

$address_especial    = exec("sed -n '70p'  /opt/MMDVM_Bridge/especial.ini");
$address_especial    = substr("$address_especial   ", 8, 30);

$port_especial = exec("sed -n '71p'  /opt/MMDVM_Bridge/especial.ini");
$port_especial = substr("$port_especial", 5, 5);

$password_especial = exec("sed -n '74p' /opt/MMDVM_Bridge/especial.ini");
$password_especial = substr("$password_especial", 9, 15);

$sala_nxdn = exec("sed -n '10p' /opt/NXDNClients/NXDNGateway/private/NXDNHosts.txt");
$sala_nxdn = substr("$sala_nxdn", 0, 5);

$selfcare = exec("sed -n '74p' /opt/MMDVM_Bridge/brandmeister_esp.ini");
$selfcare = substr("$selfcare", 9, 20);

$sala_fcs = exec("sed -n '41p' /home/pi/YSFClients/YSFGateway/YSFGateway.ini");
$sala_fcs = substr("$sala_fcs", 8, 15);

//COMPROBAMOS SI EL DVSWITCH ESTÁ ACTIVADO EN EL ESCRITORIO DE LA IMAGEN V10
$dvswitch = exec("sed -n '18p' /home/pi/status.ini");
if ($dvswitch=="DVSWITCH=ON"){
?>
<!-- ============================================== -->

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="Dvswitch Mobile">
    <meta name="description" content="Dvswitch Mobile">
    <meta name="author" content="EA3EIZ">

<!-- refresca la página cada 10 segundo (implantado por mi) -->
<!-- ====================================================== -->
<!-- <meta http-equiv="refresh" content="5" /> -->

<link rel="shortcut icon" href="img/BOLA_MUNDO_ADER.png">
    <title>DV_ADER</title>
    <!-- CSS Bootstrap-->
    <link href="custom/bootstrap/css/bootstrap.css" rel="stylesheet">
    
    <!-- CSS tema -->
    <link href="css/freelancer.css" rel="stylesheet">
    
    <!-- <Fuentes -->
    <link href="custom/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css">

<style type="text/css">
body{
    background-image: url(../../img/fondo_02.png);
    }
.sistema{
    height: 50px;
    color:#FFFFFF;
    font-size: 25px;
    padding-top: 5px;
    text-align: center;
    background:#108040;
    border-radius: 4px 4px 4px 4px;
    }
header {
    text-align: center;
    height:auto;
    background-image: url(../img/fondo_02.png);
    color: white;
    background: no-repeat;
}
.color_rojo{
    color: #FC0107;
    font-size: 22px;
    background: #000000;
    }
.color_verde{
    color:#21FF06;
    font-size: 22px;
    background: #000000;
    }
.version{
    height: 50px;
    color:#FFFFFF;
    font-size: 20px;
    padding-top: 8px;
    text-align: center;
    background:#000000;
    border-radius: 4px 4px 4px 4px;
    }    
.callsign{
    height: 50px;
    color:#FFFFFF;
    font-size: 22px;
    padding-top: 10px;
    text-align: center;
    background:#FD8008;
    border-radius: 4px 4px 4px 4px;
    } 
.ipcs2{
    color:#000000;
    font-size: 25px;
    padding-top: 11px;
    } 
@media (max-width: 360px) {
.ipcs2{
    color:#000000;
    font-size: 18px;
    padding-top: 11px;
    }
    .sistema{
    height: 50px;
    color:#FFFFFF;
    font-size: 18px;
    padding-top: 5px;
    text-align: center;
    background:#108040;
    border-radius: 4px 4px 4px 4px;
    } 
}
@media (min-width: 375px) {
.ipcs2{
    color:#000000;
    font-size: 18px;
    padding-top: 11px;
    }
    .sistema{
    height: 50px;
    color:#FFFFFF;
    font-size: 18px;
    padding-top: 5px;
    text-align: center;
    background:#108040;
    border-radius: 4px 4px 4px 4px;
    } 
}
@media (min-width: 760px) {
.ipcs2{
    color:#000000;
    font-size: 25px;
    padding-top: 11px;
    }
    .sistema{
    height: 50px;
    color:#FFFFFF;
    font-size: 25px;
    padding-top: 5px;
    text-align: center;
    background:#108040;
    border-radius: 4px 4px 4px 4px;
    } 
}
.ambe{
    height: 500px;
    color:#FFFFFF;
    font-size: 26px;
    padding-top: 5px;
    text-align: center;
    background:#800080;
    border-radius: 4px 4px 4px 4px;
    }
.ambe_desactivado{
    margin-top: 1px;
    margin-bottom: 7px;
    width: 100%;
    height: 41px;
    text-align:center;
    padding: 0px 0px 0px 0px;
    background-color: #000000;
    border-radius: 5px 5px 5px 5px;
    font-size: 24px;
    color:#F00000;
    border: 1px solid #ccc;
}
.ambe_activado{
    margin-top: 1px;
    margin-bottom: 7px;
    width: 100%;
    height: 41px;
    text-align:center;
    padding: 0px 0px 0px 0px;
    background-color: #108040;
    border-radius: 5px 5px 5px 5px;
    font-size: 24px;
    color:#FFFFFF;
    border: 1px solid #ccc;
}       
.color_naranja{
    color:#21FF06;
    }    
.fuente_boton{
    font-size:16px;
    color:#FFFFFF;
    }
.fuente_boton1{
    font-size:18px;
    color:#f00000;
    }
.fuente_boton2{
    font-size:14px;
    color:#FFFFFF;
    }
.fuente_boton3{
    font-size:15px;
    color:#f00000;
    }
.config{
    background:#000000;
    border-radius: 8px 8px 8px 8px;
    }
.config_especial{
    height: 440px;
    background:#091398;
    border-radius: 8px 8px 8px 8px;
    }
h4{
    text-align:center;
    color:#FFFFFF;
    font-size:24px;
} 
h5{
    text-align:center;
    color:#FFFFFF;
    font-size:18px;
   text-transform: none;
} 
h6{
    text-align:center;
    color:#FFFFFF;
    font-size:14px;
}  
.fondo_datos{
    margin-top: 1px;
    margin-bottom: 7px;
    width: 100%;
    height: 25px;
    text-align:center;
    padding: 0px 0px 0px 0px;
    background-color: #4C4C4C;
    border-radius: 5px 5px 5px 5px;
    font-size: 16px;
    color:#FFFFFF;
    border: 1px solid #ccc;
}
.form-control {
    height: 25px;
    text-align: center;
    font-size: 16px;
}
</style>
</head>
<body>

    <!-- Navigation -->
    <nav id="mainNav" class="navbar navbar-default navbar-fixed-top navbar-custom">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span> Menu <i class="fa fa-bars"></i>
                </button>
                    <a href="http://associacioader.com" class="img-responsive"><img src="img/Logo_Ader.png" width="150" alt=""></a>
            </div>
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                
            </div>
        </div>
    </nav>

<div class="container"> 
<br><br><br><br><br><br>














<br>


<div class="row">      
 
<!--============== CAJA LOGIN ====================================-->

<div class="col-md-6 ambe">

    <h5>CONFIGURACIÓN AMBE SERVER</h5>

<?php
    if ($ambe_activo=="true"){
?>
        <div class="ambe_desactivado">
            <span>Ambe server desactivado</span>
        </div>
<?php
}
    else {
?>
        <div class="ambe_activado">
            <span>Ambe server activado</span>
        </div>
<?php
}
?>

<form method="post" action="cambia_ip_ambe.php"/><br>
        <input name="ip_ambe" class="fuente_boton3 form-control" placeholder="Introduce IP + Enter">
            <div class="fondo_datos">IP: 
                <span class="color_naranja"><?php echo $ip_ambe;?></span>
            </div>         
</form>
<br>
<form method="post" action="cambia_puerto_ambe.php"/>
        <input name="puerto_ambe" class="fuente_boton3 form-control" placeholder="Introduce Puerto Router + Enter">
            <div class="fondo_datos">Puerto Router: 
                <span class="color_naranja"><?php echo $puerto_ambe;?></span>
            </div>         
</form>

<form method="post" action="cambia_activa_ambe.php"/>
    <button class="btn btn-success btn-sm btn-block" type="submit">ACTIVAR AMBE SERVER</button>
</form>

<br>

<form method="post" action="cambia_desactiva_ambe.php"/>
    <button class="btn btn-danger btn-sm btn-block" type="submit">DESACTIVAR AMBE SERVER</button>
</form>
<br>

<form method="post" action="../../index.php">
    <button class="btn btn-warning btn-sm btn-block" type="submit">VOLVER AL DASHBOARD</button>
</form>
</div>























</div><!-- row -->

<!--============== FIN CAJA LOGIN ====================== -->

</div><!-- container -->

    <header>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="intro-text">
                                            </div>
                </div>
            </div>
        </div>

    </header>
    

    <?php
    //EL DVSWITCH NO ESTÁ ACTIVADO Y NO ABRE LA PAGINA DEL DVSWITCH
}else {
header('Location: dvswitch_desactivado.php');    
}
?>
    <!-- jQuery -->
    <script src="custom/jquery/jquery.min.js"></script>
    <script src="custom/bootstrap/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>
    <script src="js/freelancer.min.js"></script>
<script>
function parpadear() {
with (document.getElementById("parpadeo").style)
visibility = (visibility == "visible") ? "hidden" : "visible";
}
</script>


<script>
function esconde_div(){
   var elemento = document.getElementById("activado");
   elemento.style.display = 'none';
}
 
function visible_div(){
   var elemento = document.getElementById("activado");
   elemento.style.display = 'block';
}
</script>

</body>
</html>
