<?php 
session_start();
//Pasar a ESPECIAL

//PARAR LOS SERVICIOS
exec("sudo systemctl stop ysfgateway.service");
exec("sudo systemctl stop dmr2ysf.service");
exec("sudo systemctl stop analog_bridge.service");
exec("sudo systemctl stop md380-emu.service");
exec("sudo systemctl stop mmdvm_bridge.service");
exec("sudo systemctl stop nxdngatewayd.service");

exec("sudo cp /opt/MMDVM_Bridge/MMDVM_Bridge_ESPECIAL.ini /opt/MMDVM_Bridge/MMDVM_Bridge.ini");

// RESTAURA LOS SERVICIOS
exec("sudo systemctl restart analog_bridge.service");
exec("sudo systemctl restart md380-emu.service");
exec("sudo systemctl restart mmdvm_bridge.service");

	
?>
<!DOCTYPE html>
<html>
<head>
     <meta charset="UTF-8"> 
     <meta http-equiv="content-type" content="text/html">
     <meta name="author" content="EA3EIZ">
     <link rel="shortcut icon" href="imagenes/favicon.png" type="image/x-icon" />
     <title>cambiando</title>
     <meta http-equiv="refresh" content="2; url=../../index.php" />

    <!-- CSS Bootstrap-->
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="custom/bootstrap/css/bootstrap.css" rel="stylesheet">

     <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>

<style>
    body{
    background:#333;
    }
    .texto_centrado_blanco{
    padding-top: 60px;
    color: #FFFFFF;
    font-size: 30px;
    text-align: center;
    }
    .config_especial{
    height: 200px;
    background:#8000FF;
    border-radius: 8px 8px 8px 8px;
    }    
</style>

</head>
<body>
 <div class="container"> 
 	<br><br>
        <div class="row">
               <div class="col-md-6 col-md-offset-3 config_especial">    
               <h1 class="texto_centrado_blanco">INICIANDO MODO ESPECIAL</h1>
               </div> 	                       
        </div><!--  row -->
</div><!--container-->

<!-- JavaScript================================================== -->
    <script src="js/bootstrap.min.js"></script>
</body>
</html>
