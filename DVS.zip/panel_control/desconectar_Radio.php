<?php		
	exec("cd /home/pi/V7; sudo sh cerrar_mmdvm_30.sh");
	header("Location: panel_control.php");
?>