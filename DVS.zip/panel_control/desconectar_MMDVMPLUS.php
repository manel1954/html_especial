<?php		
	exec("cd /home/pi/V7; sudo sh cerrar_plus_30.sh");
	header("Location: panel_control.php");
?>