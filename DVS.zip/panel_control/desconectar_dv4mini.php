<?php

//exec("sudo killall Main");
exec("cd /home/pi/V30; sudo sh cerrar_dv4_30.sh");
header("Location: panel_control.php");

?>

