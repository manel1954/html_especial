<?php
exec("cd /home/pi/V30; sudo sh ejecutar_svxlink_30.sh");
header("Location: panel_control.php");
   
      ?>
