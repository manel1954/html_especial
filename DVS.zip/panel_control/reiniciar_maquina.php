<?php
          
      exec("sudo reboot; ");
         
      header("Location: panel_control.php");
   
      ?>
