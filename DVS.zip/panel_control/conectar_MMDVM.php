<?php

exec("cd /home/pi; sudo sh ejecutar_mmdvm.sh");
header("Location: panel_control.php");
?>
