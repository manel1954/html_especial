<?php
exec("cd /home/pi/V6; sudo sh cerrar_YSF2DMR.sh");
header("Location: panel_control.php");

?>

