<?php
          
      exec("sudo poweroff");
         
      header("Location: login.php");
   
      ?>
