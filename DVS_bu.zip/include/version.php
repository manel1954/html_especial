<?php
define("VERSION", "Ver 1.6.9");
define("DASH", "ShaYmez-20230102");
?>