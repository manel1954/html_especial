<div style="width: 1100px;">
<p style="text-align: center;"><span style="text-align: center;">
Cortney T. Buffington, N0MJS. <a target="_blank" href="https://github.com/ShaYmez/hblink3">HBlink3.</a>  Copyright &copy; 2016-2023<br>The Regents of the <a target="_blank" href=http://k0usy.mystrikingly.com/>K0USY Group</a>. All Rights Reserved.<br><a title="HBMonv2 SP2ONG v20211012" target="_blank" href=https://github.com/sp2ong/HBMonv2>Version SP2ONG 2019-2023</a><br><a title="HBlink Docker by Shaymez" target="_blank" href=https://github.com/shaymez/hblink-docker-installer>Docker Version 1.6.9</a><br></span>
    <!-- THIS COPYRIGHT NOTICE MUST BE DISPLAYED AS A CONDITION OF THE LICENCE GRANT FOR THIS SOFTWARE. ALL DERIVATEIVES WORKS MUST CARRY THIS NOTICE -->
    <!-- This is version of HBMonitor SP2ONG 2019-2023 -->
    <!-- HBlink Docker Installer ShaYmez 2021-2023 -->
</p>
</div>